// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

// index.js is used to setup and configure your bot

// Import required packages
const path = require('path');

// Note: Ensure you have a .env file and include the MicrosoftAppId and MicrosoftAppPassword.
const ENV_FILE = path.join(__dirname, '.env');
require('dotenv').config({ path: ENV_FILE });

const restify = require('restify');

// Import required bot services.
// See https://aka.ms/bot-services to learn more about the different parts of a bot.
// const { BotFrameworkAdapter } = require('botbuilder');
const {
    CloudAdapter,
    ConfigurationServiceClientCredentialFactory,
    createBotFrameworkAuthenticationFromConfiguration
} = require('botbuilder');

// Connect to blob storage; preserve conversation references
// const { BlobStorage } = require('botbuilder-azure');
const { DefaultAzureCredential } = require('@azure/identity');
const { BlobServiceClient } = require('@azure/storage-blob');
const defaultAzureCredential = new DefaultAzureCredential();

// This bot's main dialog.
const { ProactiveBot } = require('./bots/proactiveBot');

const credentialsFactory = new ConfigurationServiceClientCredentialFactory({
    MicrosoftAppId: process.env.MicrosoftAppId,
    MicrosoftAppPassword: process.env.MicrosoftAppPassword,
    MicrosoftAppType: process.env.MicrosoftAppType,
    MicrosoftAppTenantId: process.env.MicrosoftAppTenantId
});

const botFrameworkAuthentication = createBotFrameworkAuthenticationFromConfiguration(null, credentialsFactory);

// Create adapter.
// See https://aka.ms/about-bot-adapter to learn more about adapters.
// const adapter = new BotFrameworkAdapter({
//     appId: process.env.MicrosoftAppId,
//     appPassword: process.env.MicrosoftAppPassword
// });

const adapter = new CloudAdapter(botFrameworkAuthentication);

// Define storage
// const myStorage = new BlobStorage({
//     containerName: process.env.BlobContainerName,
//     storageAccountOrConnectionString: process.env.BlobConnectionString});

// const blobServiceClient = BlobServiceClient.fromConnectionString(process.env.BlobConnectionString);
const blobServiceClient = new BlobServiceClient(
        `https://${process.env.accountName}.blob.core.windows.net`,
        defaultAzureCredential
    );
const containerClient = blobServiceClient.getContainerClient(process.env.BlobContainerName);

// Catch-all for errors.
adapter.onTurnError = async (context, error) => {
    // This check writes out errors to console log .vs. app insights.
    // NOTE: In production environment, you should consider logging this to Azure
    //       application insights. See https://aka.ms/bottelemetry for telemetry 
    //       configuration instructions.
    //console.log(context);
    console.error(`\n [onTurnError] unhandled error: ${error}`);

    // Send a trace activity, which will be displayed in Bot Framework Emulator
    await context.sendTraceActivity(
        'OnTurnError Trace',
        `${error}`,
        'https://www.botframework.com/schemas/error',
        'TurnError'
    );

    // Send a message to the user
    await context.sendActivity('The bot encountered an error or bug.');
    await context.sendActivity('To continue to run this bot, please fix the bot source code.');
};


// Create the main dialog.
const conversationReferences = {};
// const bot = new ProactiveBot(conversationReferences, myStorage);
const bot = new ProactiveBot(conversationReferences, containerClient);

// Create HTTP server.
const server = restify.createServer();
server.use(restify.plugins.queryParser());
server.use(restify.plugins.bodyParser({
    // requestBodyOnGet: true
}));

server.listen(process.env.port || process.env.PORT || 3978, function() {
    console.log(`\n${ server.name } listening to ${ server.url }`);
    console.log('\nGet Bot Framework Emulator: https://aka.ms/botframework-emulator');
    console.log('\nTo talk to your bot, open the emulator select "Open Bot"');
});

// Listen for incoming activities and route them to your bot main dialog.
server.post('/api/messages', async (req, res) => {
    // Route received a request to adapter for processing
    await adapter.process(req, res, (context) => bot.run(context));
});


// Listen for incoming notifications and send proactive messages to users.
server.post('/api/notify', async (req, res) => {
    console.log('/api/notify hello');
    var msgContent = req.query.msg
    console.log('/api/notify req parameter = ' + msgContent);

    try {
        for await (const userRef of containerClient.listBlobsFlat()) {
            // Get a block blob client
            const blockBlobClient = containerClient.getBlockBlobClient(userRef.name);   
            // Get blob content from position 0 to the end
            const downloadBlockBlobResponse = await blockBlobClient.download(0);
            console.log("\nDownloaded blob content...");
            const conversationReference = await streamToJson(downloadBlockBlobResponse.readableStreamBody);
            console.log('/api/notify in the loop');
            await adapter.continueConversationAsync(process.env.MicrosoftAppId, conversationReference, async context => {
                console.log('/api/notify in the adapter await');
                await context.sendActivity(msgContent);
            });
            // console.log(downloadBlockBlobResponse.readableStreamBody);
        }
        
        // for await (const cvst of cvstList){
        //     console.log(cvst);
        // }
    } catch (error) {
        console.log('/api/notify has error: ');
        console.log(error);
    } finally {
        console.log('/api/notify hello 4');
        res.setHeader('Content-Type', 'text/html');
        res.writeHead(200);
        res.write('<html><body><h1>Success to send a proactive messages.</h1></body></html>');
        res.end();
    }
});

// Convert stream to text
async function streamToJson(readable) {
    readable.setEncoding('utf8');
    let data = '';
    for await (const chunk of readable) {
        data += chunk;
    }
    
    return JSON.parse(data);
}