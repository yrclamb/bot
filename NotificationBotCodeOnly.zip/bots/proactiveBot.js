// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

const { ActivityHandler, TurnContext } = require('botbuilder');

class ProactiveBot extends ActivityHandler {
    constructor(conversationReferences, containerClient) {
        super();

        // Dependency injected dictionary for storing ConversationReference objects used in NotifyController to proactively message users
        this.conversationReferences = conversationReferences;
        this.containerClient = containerClient;

        this.onConversationUpdate(async (context, next) => {
            this.addConversationReference(context.activity);

            await next();
        });

        this.onMembersAdded(async (context, next) => {
            const membersAdded = context.activity.membersAdded;
            for (let cnt = 0; cnt < membersAdded.length; cnt++) {
                if (membersAdded[cnt].id !== context.activity.recipient.id) {
                    const welcomeMessage = 'Hello there, let us start a connection to company information !';
                    await context.sendActivity(welcomeMessage);
                }
            }

            // By calling next() you ensure that the next BotHandler is run.
            await next();
        });

        this.onMessage(async (context, next) => {
            this.addConversationReference(context.activity);

            // Echo back what the user said
            await context.sendActivity(`You sent '${ context.activity.text }'`);
            await next();
        });
    }

    async addConversationReference(activity) {
        const conversationReference = TurnContext.getConversationReference(activity);
        this.conversationReferences[conversationReference.user.aadObjectId] = conversationReference;
        console.log(conversationReference.user.aadObjectId);
        console.log(JSON.stringify(conversationReference));
        // const cvstDict = {};
        // cvstDict[conversationReference.user.aadObjectId] = JSON.stringify(conversationReference)
        const userRef = JSON.stringify(conversationReference)
        
        try {
            // await this.containerClient.write(cvstDict);
            const blockBlobClient = this.containerClient.getBlockBlobClient(conversationReference.user.aadObjectId);
            const uploadBlobResponse = await blockBlobClient.upload(userRef, userRef.length);
            console.log(`Blob was uploaded successfully. requestId: ${uploadBlobResponse.requestId}`);
            console.log('success stored to blob');
        } catch (err){
            console.log(`failed to write, err = ${err}`);
        }
    }
}

module.exports.ProactiveBot = ProactiveBot;